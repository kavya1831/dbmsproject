import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Exhibition extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Exhibition frame = new Exhibition();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Exhibition() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 377);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblExhibition = new JLabel("EXHIBITION");
		lblExhibition.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblExhibition.setBounds(155, 16, 121, 20);
		contentPane.add(lblExhibition);
		
		JLabel lblExhid = new JLabel("EXH_ID");
		lblExhid.setBounds(15, 51, 69, 20);
		contentPane.add(lblExhid);
		
		textField = new JTextField();
		textField.setBounds(194, 48, 146, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblExhname = new JLabel("EXH_NAME");
		lblExhname.setBounds(15, 92, 90, 20);
		contentPane.add(lblExhname);
		
		textField_1 = new JTextField();
		textField_1.setBounds(194, 90, 146, 26);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblStartdate = new JLabel("START_DATE");
		lblStartdate.setBounds(15, 139, 105, 20);
		contentPane.add(lblStartdate);
		
		textField_2 = new JTextField();
		textField_2.setBounds(194, 136, 146, 26);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblEnddate = new JLabel("END_DATE");
		lblEnddate.setBounds(15, 180, 105, 20);
		contentPane.add(lblEnddate);
		
		textField_3 = new JTextField();
		textField_3.setBounds(194, 178, 146, 26);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="INSERT INTO EXHIBITION values('"+textField.getText()+"','"+textField_1.getText()+"','"+textField_2.getText()+"','"+textField_3.getText()+"')";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "Success!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");					
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnInsert.setBounds(5, 225, 115, 29);
		contentPane.add(btnInsert);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="DELETE FROM  EXHIBITION WHERE EXH_ID='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "DELETED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnDelete.setBounds(155, 225, 115, 29);
		contentPane.add(btnDelete);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="UPDATE EXHIBITION  SET  EXH_NAME='"+textField_1.getText()+"',START_DATE='"+textField_2.getText()+"',END_DATE='"+textField_3.getText()+"' WHERE EXH_ID='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "UPDATED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField.requestFocusInWindow();
			}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnUpdate.setBounds(298, 225, 115, 29);
		contentPane.add(btnUpdate);
		
		JButton btnSearch = new JButton("SEARCH");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","kavya","kavya");
					String sql="select * from EXHIBITION where exh_id='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					if(rs.next()==false)
					{
					  JOptionPane.showMessageDialog(null, "NO SUCH RECORDS INVALID EXH_ID");
					  textField.setText("");
					  textField.requestFocusInWindow();
					}
					else
					{
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
						textField_3.setText(rs.getString(4));
					}
					
					
				}
				catch(Exception e1)
				{
					System.out.println("error"+e1);
					
				}
			}
		});
		btnSearch.setBounds(5, 270, 115, 29);
		contentPane.add(btnSearch);
		
		JButton btnClear = new JButton("CLEAR");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
			}
		});
		btnClear.setBounds(155, 270, 115, 29);
		contentPane.add(btnClear);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Menu.main(null);
			}
		});
		btnHome.setBounds(298, 270, 115, 29);
		contentPane.add(btnHome);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Exhibition.class.getResource("/Images/b45de1af6cfa9c106aea0914183b9104.jpg")));
		lblNewLabel.setBounds(-11, 0, 451, 321);
		contentPane.add(lblNewLabel);
	}

}
