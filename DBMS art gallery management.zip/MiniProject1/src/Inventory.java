import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;

public class Inventory extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inventory frame = new Inventory();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Inventory() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 335);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblInventory = new JLabel("INVENTORY");
		lblInventory.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblInventory.setBounds(159, 16, 124, 20);
		contentPane.add(lblInventory);
		
		JLabel lblArtid = new JLabel("ART_ID");
		lblArtid.setForeground(Color.WHITE);
		lblArtid.setBounds(15, 51, 69, 20);
		contentPane.add(lblArtid);
		
		textField = new JTextField();
		textField.setBounds(169, 48, 146, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblExhid = new JLabel("EXH_ID");
		lblExhid.setForeground(Color.WHITE);
		lblExhid.setBounds(15, 94, 69, 20);
		contentPane.add(lblExhid);
		
		textField_1 = new JTextField();
		textField_1.setBounds(169, 91, 146, 26);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblQuantity = new JLabel("QUANTITY");
		lblQuantity.setForeground(Color.WHITE);
		lblQuantity.setBounds(15, 137, 101, 20);
		contentPane.add(lblQuantity);
		
		textField_2 = new JTextField();
		textField_2.setBounds(169, 134, 146, 26);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="INSERT INTO INVENTORY values('"+textField.getText()+"','"+textField_1.getText()+"','"+textField_2.getText()+"')";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "Success!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
						
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnInsert.setBounds(15, 190, 115, 29);
		contentPane.add(btnInsert);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="DELETE FROM  INVENTORY WHERE ART_ID='"+textField.getText()+"'  AND EXH_ID='"+textField_1.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "DELETED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
				 }
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnDelete.setBounds(159, 190, 115, 29);
		contentPane.add(btnDelete);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="UPDATE INVENTORY  SET  EXH_ID='"+textField_1.getText()+"',QTY='"+textField_2.getText()+"' WHERE ART_ID='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "UPDATED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField.requestFocusInWindow();
			}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnUpdate.setBounds(298, 190, 115, 29);
		contentPane.add(btnUpdate);
		
		JButton btnSearch = new JButton("SEARCH");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","kavya","kavya");
					String sql="select * from INVENTORY where art_id='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					if(rs.next()==false)
					{
					  JOptionPane.showMessageDialog(null, "NO SUCH RECORDS INVALID ART_ID");
					  textField.setText("");
					  textField.requestFocusInWindow();
					}
					else
					{
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
					}
					
					
				}
				catch(Exception e1)
				{
					System.out.println("error"+e1);
					
				}
			}
		});
		btnSearch.setBounds(15, 234, 115, 29);
		contentPane.add(btnSearch);
		
		JButton btnClear = new JButton("CLEAR");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
			}
		});
		btnClear.setBounds(159, 234, 115, 29);
		contentPane.add(btnClear);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Menu.main(null);
			}
		});
		btnHome.setBounds(298, 234, 115, 29);
		contentPane.add(btnHome);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Inventory.class.getResource("/Images/48cd8536854091cd243bd1f97c142a28.jpg")));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(0, 0, 428, 279);
		contentPane.add(lblNewLabel);
	}

}
