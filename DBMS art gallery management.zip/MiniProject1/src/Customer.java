import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Customer extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Customer frame = new Customer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Customer() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 490);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCustomer = new JLabel("CUSTOMER");
		lblCustomer.setForeground(Color.WHITE);
		lblCustomer.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblCustomer.setBounds(162, 16, 124, 20);
		contentPane.add(lblCustomer);
		
		JLabel lblCustid = new JLabel("CUST_ID");
		lblCustid.setForeground(Color.WHITE);
		lblCustid.setBounds(15, 42, 69, 20);
		contentPane.add(lblCustid);
		
		textField = new JTextField();
		textField.setBounds(189, 39, 146, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblCname = new JLabel("CNAME");
		lblCname.setForeground(Color.WHITE);
		lblCname.setBounds(15, 87, 69, 20);
		contentPane.add(lblCname);
		
		textField_1 = new JTextField();
		textField_1.setBounds(189, 81, 146, 26);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblMoneyspent = new JLabel("MONEY_SPENT");
		lblMoneyspent.setForeground(Color.WHITE);
		lblMoneyspent.setBounds(15, 123, 124, 20);
		contentPane.add(lblMoneyspent);
		
		textField_2 = new JTextField();
		textField_2.setBounds(189, 123, 146, 26);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblAddress = new JLabel("ADDRESS");
		lblAddress.setForeground(Color.WHITE);
		lblAddress.setBounds(15, 168, 94, 20);
		contentPane.add(lblAddress);
		
		textField_3 = new JTextField();
		textField_3.setBounds(189, 165, 146, 26);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblArtistid = new JLabel("ARTIST_ID");
		lblArtistid.setForeground(Color.WHITE);
		lblArtistid.setBounds(15, 208, 94, 20);
		contentPane.add(lblArtistid);
		
		textField_4 = new JTextField();
		textField_4.setBounds(189, 205, 146, 26);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblExhid = new JLabel("EXH_ID");
		lblExhid.setForeground(Color.WHITE);
		lblExhid.setBounds(15, 244, 69, 26);
		contentPane.add(lblExhid);
		
		textField_5 = new JTextField();
		textField_5.setBounds(189, 247, 146, 26);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="INSERT INTO CUSTOMER values('"+textField.getText()+"','"+textField_1.getText()+"','"+textField_2.getText()+"','"+textField_3.getText()+"','"+textField_4.getText()+"','"+textField_5.getText()+"')";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "Success!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");
					textField_5.setText("");					
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnInsert.setBounds(15, 312, 115, 29);
		contentPane.add(btnInsert);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="DELETE FROM  CUSTOMER WHERE CUST_ID='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "DELETED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");
					textField_5.setText("");
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnDelete.setBounds(148, 312, 115, 29);
		contentPane.add(btnDelete);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="UPDATE CUSTOMER  SET  CNAME='"+textField_1.getText()+"',MONEY_SPENT='"+textField_2.getText()+"',ADDRESS='"+textField_3.getText()+"',ARTIST_ID='"+textField_4.getText()+"' ,EXH_ID='"+textField_5.getText()+"'WHERE CUST_ID='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "UPDATED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");
					textField_5.setText("");
					textField.requestFocusInWindow();
			}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnUpdate.setBounds(283, 312, 115, 29);
		contentPane.add(btnUpdate);
		
		JButton btnSearch = new JButton("SEARCH");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","kavya","kavya");
					String sql="select * from CUSTOMER where cust_id='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe =con.prepareStatement(sql);
					rs =exe.executeQuery();
					if(rs.next()==false)
					{
					  JOptionPane.showMessageDialog(null, "NO SUCH RECORDS INVALID CUST_ID");
					  textField.setText("");
					  textField.requestFocusInWindow();
					}
					else
					{
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
						textField_3.setText(rs.getString(4));
						textField_4.setText(rs.getString(5));
						textField_5.setText(rs.getString(6));
					}
				}
				catch(Exception e1)
				{
					System.out.println("error"+e1);
					
				}
			}
		});
		btnSearch.setBounds(15, 364, 115, 29);
		contentPane.add(btnSearch);
		
		JButton btnClear = new JButton("CLEAR");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
				
			}
		});
		btnClear.setBounds(148, 364, 115, 29);
		contentPane.add(btnClear);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Menu.main(null);
			}
		});
		btnHome.setBounds(283, 364, 115, 29);
		contentPane.add(btnHome);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Customer.class.getResource("/Images/24d7adecc222efcef6788285b2aba1d3.jpg")));
		lblNewLabel.setBounds(0, 1, 439, 434);
		contentPane.add(lblNewLabel);
	}

}
