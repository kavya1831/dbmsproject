import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Menu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 503, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblHome = new JLabel("HOME");
		lblHome.setForeground(Color.WHITE);
		lblHome.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblHome.setBounds(206, 16, 64, 20);
		contentPane.add(lblHome);
		
		JButton btnArtist = new JButton("ARTIST");
		btnArtist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
					Artist.main(null);
			}
		});
		btnArtist.setBounds(36, 74, 115, 29);
		contentPane.add(btnArtist);
		
		JButton btnArtwork = new JButton("ARTWORK");
		btnArtwork.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Artwork.main(null);
			}
		});
		btnArtwork.setBounds(167, 74, 115, 29);
		contentPane.add(btnArtwork);
		
		JButton btnExhibition = new JButton("EXHIBITION");
		btnExhibition.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Exhibition.main(null);
			}
		});
		btnExhibition.setBounds(307, 74, 145, 29);
		contentPane.add(btnExhibition);
		
		JButton btnCustomer = new JButton("CUSTOMER");
		btnCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Customer.main(null);
			}
		});
		btnCustomer.setBounds(36, 141, 115, 29);
		contentPane.add(btnCustomer);
		
		JButton btnDisplays = new JButton("DISPLAYS");
		btnDisplays.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Displays.main(null);
			}
		});
		btnDisplays.setBounds(167, 141, 115, 29);
		contentPane.add(btnDisplays);
		
		JButton btnInventory = new JButton("INVENTORY");
		btnInventory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Inventory.main(null);
			}
		});
		btnInventory.setBounds(307, 141, 137, 29);
		contentPane.add(btnInventory);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Menu.class.getResource("/Images/2237cd834898b317bca696594ed7d80d.jpg")));
		lblNewLabel.setBounds(0, 0, 481, 244);
		contentPane.add(lblNewLabel);
	}
}
