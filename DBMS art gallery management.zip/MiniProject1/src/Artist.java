import java.awt.BorderLayout;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Artist extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Artist frame = new Artist();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Artist() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 420);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblArtist = new JLabel("ARTIST");
		lblArtist.setForeground(Color.WHITE);
		lblArtist.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblArtist.setBounds(171, 16, 69, 20);
		contentPane.add(lblArtist);
		
		JLabel lblArtistid = new JLabel("ARTIST_ID");
		lblArtistid.setForeground(Color.WHITE);
		lblArtistid.setBounds(15, 53, 94, 20);
		contentPane.add(lblArtistid);
		
		textField = new JTextField();
		textField.setBounds(163, 52, 146, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblArtistname = new JLabel("ARTIST_NAME");
		lblArtistname.setForeground(Color.WHITE);
		lblArtistname.setBounds(15, 89, 124, 20);
		contentPane.add(lblArtistname);
		
		textField_1 = new JTextField();
		textField_1.setBounds(163, 86, 146, 26);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblYob = new JLabel("YOB");
		lblYob.setForeground(Color.WHITE);
		lblYob.setBounds(15, 125, 69, 20);
		contentPane.add(lblYob);
		
		textField_2 = new JTextField();
		textField_2.setBounds(163, 122, 146, 26);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblCity = new JLabel("CITY");
		lblCity.setForeground(Color.WHITE);
		lblCity.setBounds(15, 161, 69, 20);
		contentPane.add(lblCity);
		
		textField_3 = new JTextField();
		textField_3.setBounds(163, 158, 146, 26);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblCountry = new JLabel("COUNTRY");
		lblCountry.setForeground(Color.WHITE);
		lblCountry.setBounds(15, 197, 94, 20);
		contentPane.add(lblCountry);
		
		textField_4 = new JTextField();
		textField_4.setBounds(163, 194, 146, 26);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","kavya","kavya");
					String sql="INSERT INTO ARTIST VALUES ('"+textField.getText()+"','"+textField_1.getText()+"','"+textField_2.getText()+"','"+textField_3.getText()+"','"+textField_4.getText()+"')";
					PreparedStatement exe;
					ResultSet rs;
					exe=con.prepareStatement(sql);
					rs=exe.executeQuery();
					JOptionPane.showMessageDialog(null, "success!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");
					
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnInsert.setBounds(15, 248, 115, 29);
		contentPane.add(btnInsert);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="DELETE FROM  ARTIST WHERE ARTIST_ID='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "DELETED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");					
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnDelete.setBounds(156, 248, 115, 29);
		contentPane.add(btnDelete);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="UPDATE ARTIST  SET  ARTIST_NAME='"+textField_1.getText()+"',YOB='"+textField_2.getText()+"',CITY='"+textField_3.getText()+"',COUNTRY='"+textField_4.getText()+"' WHERE ARTIST_ID='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "UPDATED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");		
					textField.requestFocusInWindow();
			}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnUpdate.setBounds(287, 248, 115, 29);
		contentPane.add(btnUpdate);
		
		JButton btnSearch = new JButton("SEARCH");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","kavya","kavya");
					String sql="select * from ARTIST where artist_id='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					if(rs.next()==false)
					{
					  JOptionPane.showMessageDialog(null, "NO SUCH RECORDS INVALID ARTIST_ID");
					  textField.setText("");
					  textField.requestFocusInWindow();
					}
					else
					{
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
						textField_3.setText(rs.getString(4));
						textField_4.setText(rs.getString(5));
						
						
					}
					
					
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
					
				}
			}
		});
		btnSearch.setBounds(15, 307, 115, 29);
		contentPane.add(btnSearch);
		
		JButton btnClear = new JButton("CLEAR");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
			}
		});
		btnClear.setBounds(156, 307, 115, 29);
		contentPane.add(btnClear);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Menu.main(null);
			}
		});
		btnHome.setBounds(287, 307, 115, 29);
		contentPane.add(btnHome);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Artist.class.getResource("/Images/3bac62bb82ed27004566766ab95fe51d.jpg")));
		lblNewLabel.setBounds(0, 0, 428, 376);
		contentPane.add(lblNewLabel);
	}
}
