import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblArtGalleryManagement = new JLabel("ART GALLERY MANAGEMENT");
		lblArtGalleryManagement.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblArtGalleryManagement.setBounds(75, 16, 293, 20);
		contentPane.add(lblArtGalleryManagement);
		
		JLabel lblUserName = new JLabel("USER NAME");
		lblUserName.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblUserName.setBounds(58, 75, 102, 20);
		contentPane.add(lblUserName);
		
		textField = new JTextField();
		textField.setBounds(179, 72, 146, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblPassword = new JLabel("PASSWORD");
		lblPassword.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblPassword.setBounds(58, 136, 102, 20);
		contentPane.add(lblPassword);
		
		textField_1 = new JTextField();
		textField_1.setBounds(179, 130, 146, 26);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.setForeground(Color.BLACK);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{

					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","kavya","kavya");
					String sql="INSERT INTO LOGINPAGE VALUES ('"+textField.getText()+"','"+textField_1.getText()+"')";
					PreparedStatement exe;
					ResultSet rs;
					exe=con.prepareStatement(sql);
					rs=exe.executeQuery();
					JOptionPane.showMessageDialog(null, "success!!!");
					textField.setText("");
					textField_1.setText("");
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
				dispose();
				Menu.main(null);
			}
		});
		btnLogin.setBounds(158, 186, 115, 29);
		contentPane.add(btnLogin);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/Images/d48af2b68cd82cb8e3cf6d6ebfe98288.jpg")));
		lblNewLabel.setBounds(-14, 0, 442, 244);
		contentPane.add(lblNewLabel);
	}
}
