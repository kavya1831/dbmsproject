import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Displays extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Displays frame = new Displays();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Displays() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDisplays = new JLabel("DISPLAYS");
		lblDisplays.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblDisplays.setBounds(156, 16, 100, 20);
		contentPane.add(lblDisplays);
		
		JLabel lblExhid = new JLabel("EXH_ID");
		lblExhid.setForeground(Color.WHITE);
		lblExhid.setBounds(15, 50, 69, 20);
		contentPane.add(lblExhid);
		
		textField = new JTextField();
		textField.setBounds(147, 47, 146, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblArtid = new JLabel("ART_ID");
		lblArtid.setForeground(Color.WHITE);
		lblArtid.setBounds(15, 95, 69, 20);
		contentPane.add(lblArtid);
		
		textField_1 = new JTextField();
		textField_1.setBounds(147, 89, 146, 26);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="INSERT INTO DISPLAYS values('"+textField.getText()+"','"+textField_1.getText()+"')";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "Success!!!");
					textField.setText("");
					textField_1.setText("");
										
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnInsert.setBounds(15, 153, 115, 29);
		contentPane.add(btnInsert);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="DELETE FROM  DISPLAYS WHERE EXH_ID='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "DELETED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
				}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnDelete.setBounds(159, 153, 115, 29);
		contentPane.add(btnDelete);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Kavya","Kavya");
					String sql="UPDATE DISPLAYS  SET  ART_ID='"+textField_1.getText()+"' WHERE EXH_ID='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					JOptionPane.showMessageDialog(null, "UPDATED SUCCESSFULLY!!!");
					textField.setText("");
					textField_1.setText("");
					textField.requestFocusInWindow();
			}
				catch(Exception e)
				{
					System.out.println("error"+e);
				}
			}
		});
		btnUpdate.setBounds(298, 153, 115, 29);
		contentPane.add(btnUpdate);
		
		JButton btnSearch = new JButton("SEARCH");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","kavya","kavya");
					String sql="select * from DISPLAYS where exh_id='"+textField.getText()+"'";
					PreparedStatement exe;
					ResultSet rs;
					exe = con.prepareStatement(sql);
					rs = exe.executeQuery();
					if(rs.next()==false)
					{
					  JOptionPane.showMessageDialog(null, "NO SUCH RECORDS INVALID EXH_ID");
					  textField.setText("");
					  textField.requestFocusInWindow();
					}
					else
					{
						textField_1.setText(rs.getString(2));	
					}
					
					
				}
				catch(Exception e1)
				{
					System.out.println("error"+e1);
					
				}
			}
		});
		
		btnSearch.setBounds(15, 199, 115, 29);
		contentPane.add(btnSearch);
		
		JButton btnClear = new JButton("CLEAR");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_1.setText("");
			}
		});
		btnClear.setBounds(159, 198, 115, 29);
		contentPane.add(btnClear);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Menu.main(null);
			}
		});
		btnHome.setBounds(298, 199, 115, 29);
		contentPane.add(btnHome);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Displays.class.getResource("/Images/613ef7bd95c623bab00d9dfce5257482.jpg")));
		lblNewLabel.setBounds(0, 0, 428, 255);
		contentPane.add(lblNewLabel);
	}

}
